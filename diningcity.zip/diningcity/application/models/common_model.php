<?php
class Common_model extends CI_Model {


	function login($email, $password){
		$this->db->select('id,fname,email,password');
		$this->db->from('t_user');
		$this->db->where('email', $email);
		$this->db->where('password', md5($password));
		$this->db->limit(1);

		$query= $this->db->get();
		if($query->num_rows()==1){
			return $query->result();
		} else{
			return false;
		}

	}

	function register(){
		$fname= $this->input->post('fname');
		$email= $this->input->post('email');
		$password= md5($this->input->post('password'));

		$data =	array(
			'id' => '',
			'fname' => $fname,
			'email' => $email,
			'password' => $password
			);

		$this->db->insert('t_user', $data);

	}

	public function countAll($table_name) {
		$this->db->select('*');
		$this->db->from('t_search');		
		$query = $this->db->get();  
		$tot_rec = $query->num_rows();
		//echo $this->db->last_query();
		return $tot_rec;
	} // end of countAll	


	public function get_all_records($table_name, $where_clause) {
		//$this->db->order_by($order_by_fld,$order_by);
		//$this->db->limit($limit,$offset);
		if($where_clause!='')
		$this->db->where($where_clause);
		$this->db->select('*');
		$this->db->from('t_search');
		$query = $this->db->get();
		//echo $this->db->last_query();
		return $query; 

	} // end of get_all_records	


	public function Retrive_Record($table,$id) {
		$this->db->select('*');
		$this->db->from($table);

		$this->db->where('searchId', $id);
		$query = $this->db->get();
		echo $this->db->last_query();
		$row = $query->row_array();
		$cnt = $query->num_rows();
		//echo $cnt; 
		if($cnt > 0){
		return $row;
		}

	} 


	public function count_records($table_name,$where_clause,$field,$fieldVal) {
		$where_clause .= " AND ".$field." = '".$fieldVal."'";
		//echo $where_clause;
		//exit;
		//$this->db->order_by($order_by_fld,$order_by);
		//$this->db->limit($limit,$offset);
		if($where_clause!='')
		$this->db->where($where_clause);
        //$this->db->distinct();		
		$this->db->select('*');
		$this->db->from($table_name);
		//$this->db->join('t_cuisines','t_cuisines.cuisineId = t_search.cuisineId');

		$query = $this->db->get();
		//echo $this->db->last_query();
		//exit;
		//return $query; 
        return $query->num_rows();
	}	

	public function search($table,$resTitle,$location,$limit,$start) {
        //$this->db->distinct('t_srch_cuis.searchId');		
		$this->db->select('*');
		$this->db->from($table);
		$this->db->join('t_location', 't_location.locId = t_search.locId');		
		$this->db->join('t_type', 't_type.typeId = t_search.type');		
		$this->db->join('t_city', 't_city.cityId = t_search.cityId');		
		//$this->db->join('t_address','t_address.locId = t_location.locId');
		$this->db->join('t_address','t_address.addId = t_search.addId');
		$this->db->join('t_cuisines','t_cuisines.cuisineId = t_search.cuisineId');

		//$this->db->join('t_srch_cuis','t_search.searchId =  t_srch_cuis.searchId');
		//$this->db->join('t_cuisines','t_srch_cuis.cuisineId =  t_cuisines.cuisineId');
	

		//$this->db->join('t_cuisines','t_cuisines.cuisineId IN(t_search.cuisineId)');

		//$sql = "select cuisine_name from t_search, t_cuisines where t_cuisines.cuisineId = t_search.cuisineId";
		//$queryA =  $this->db->query($sql);
		//return $queryA->result();

		//$this->db->join('t_cuisines','t_cuisines.cuisineId = t_search.cuisineId');
		//$this->db->where_in('t_search.cuisineId', $names);		

		if($resTitle!= ""){	
        $this->db->like('res_name',$resTitle);
        $this->db->or_like('t_type.type_name',$resTitle);
        $this->db->limit($limit, $start);

        }
        if($location!= ""){
        $this->db->or_like('t_address.add_details',$location);
		$this->db->or_like('t_location.loc_name',$location);
        $this->db->limit($limit, $start);
	    }

	    /*if($resTitle!= "" && $location!= ""){
        $this->db->like('res_name',$resTitle);
        $this->db->or_like('t_type.type_name',$resTitle);

        $this->db->or_like('t_address.add_details',$location);
		$this->db->or_like('t_location.loc_name',$location);        
        $this->db->limit($limit, $start);	    	
	    } */


		//$this->db->join('t_cuisines','t_cuisines.cuisineId  = t_search.cuisineId');
		//$this->db->where('t_cuisines.cuisineId',$field);

        $query = $this->db->get();
		//echo $this->db->last_query();
        return $query->result();

	}


	/*public function srchLoc($table,$location,$limit,$start){
		$this->db->select('*');
		$this->db->from($table);
		$this->db->join('t_location', 't_location.locId = t_search.locId');		
		$this->db->join('t_city', 't_city.cityId = t_search.cityId');		
		//$this->db->join('t_address','t_address.locId = t_location.locId');
		$this->db->join('t_address','t_address.addId = t_search.addId');

		$this->db->like('t_location.loc_name',$location);
        $this->db->or_like('t_address.add_details',$location);


        $this->db->limit($limit, $start);
        $query = $this->db->get();
		echo $this->db->last_query();
        return $query->result();		

	} */
	
	public function res_count($cnt, $loc) {

		/*if($cnt == "NIL" || $loc == "NIL"){
			$cnt= "";	
			$loc= "";
		} 	*/
		//echo $cnt;
		//echo $loc;
		$this->db->select('*');
		$this->db->from('t_search');	
		$this->db->join('t_location', 't_location.locId = t_search.locId');		
		$this->db->join('t_city', 't_city.cityId = t_search.cityId');	
		$this->db->join('t_address','t_address.addId = t_search.addId');
		$this->db->join('t_cuisines','t_cuisines.cuisineId = t_search.cuisineId');		

		$this->db->join('t_type', 't_type.typeId = t_search.type');		

		if($cnt != ""){
        $this->db->like('res_name',$cnt);
        $this->db->or_like('t_type.type_name',$cnt);
   		}
   		if($loc  != ""){
        $this->db->or_like('t_address.add_details',$loc);
		$this->db->or_like('t_location.loc_name',$loc);
	    }
		$query = $this->db->get();  
		$tot_rec = $query->num_rows();


	    /*if($cnt!= "" && $loc!= ""){
        $this->db->like('res_name',$cnt);
        $this->db->or_like('t_type.type_name',$cnt);

        $this->db->or_like('t_address.add_details',$loc);
		$this->db->or_like('t_location.loc_name',$loc);        
	    } */

		//echo $this->db->last_query();
		return $tot_rec;
	} // end of countAll		
	
	

	/*public function get_All_location($table_name, $where_clause) {
		//$this->db->order_by($order_by_fld,$order_by);
		//$this->db->limit($limit,$offset);
		$sql= "Select searchId,loc_name from $table_name t1,t_search t2 where t1.locId=t2.locId and t2.searchId like '%$where_clause%'";
		$query = $this->db->query($sql);
		echo $this->db->last_query();
		return $query->result(); 

	} // end of get_all_records	*/

	public function get_all_distinct_records($table_name,$field) {
        $this->db->distinct();		
		$this->db->select($field);
        //$this->db->order_by($field, "asc");
		$this->db->from($table_name);        
		//$this->db->join('t_cuisines','t_cuisines.cuisineId = t_search.cuisineId');
		$query = $this->db->get();
		//echo $this->db->last_query();
		//exit;
		return $query; 

	} // end of get_all_records	


}
?>	