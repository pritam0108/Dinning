 <?php $this->load->view("header"); ?>
 <?php $this->load->view("sticky_header"); ?>

 <div class="container" style="margin-top: 20px; margin-bottom: 20px;">
	<div class="row panel">
		<div class="col-md-4 bg_blur ">
			<div class="bg_blur-inner">
				<h2><span>Welcome</span> To DiningCity</h2>
				<h6><a href="#" class="follow_btn">Follow</a></h6>
			</div>
		</div>
        <div class="col-md-8  col-xs-12">
           <img src="http://localhost/diningcity/images/pizza3.jpg" class="img-thumbnail picture-profile hidden-xs" />
           <div class="header-profile">
                <h1>Lorem Ipsum</h1>
                <h4>Web Developer</h4>
                <span>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."
"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</span>
           </div>
        </div>
    </div> 
	<div class="row">
	<div class="col-md-3 col-sm-3">
		<div class="card hovercard">
                <div class="cardheader">

                </div>
                <div class="avatar">
                    <img alt="" src="http://localhost/diningcity/images/pizza3.jpg">
                </div>
                <div class="info">
                    <div class="title">
                        <a target="_blank" href="#">Lorem Ipsum</a>
                    </div>
                    <div class="desc desc1">Web Developer</div>
                    <div class="desc">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...</div>
                </div>
                <div class="bottom">
                    <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a class="btn btn-danger btn-sm" rel="publisher"
                       href="https://plus.google.com/+ahmshahnuralam">
                        <i class="fa fa-google-plus"></i>
                    </a>
                    <a class="btn btn-primary btn-sm" rel="publisher"
                       href="https://plus.google.com/shahnuralam">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                        <i class="fa fa-behance"></i>
                    </a>
                </div>
            </div>
	</div>
	<div class="col-md-6 col-sm-6">
		<!-- Nav tabs -->
		<div class="card">
		<ul class="nav nav-tabs-seating" role="tablist">
			<li role="presentation" class="active"><a href="#Profile" aria-controls="home" role="tab" data-toggle="tab">Edit Profile</a></li>
			<li role="presentation"><a href="#Notification" aria-controls="Notification" role="tab" data-toggle="tab">Notification Preferences</a></li>
			<li role="presentation"><a href="#Security" aria-controls="messages" role="tab" data-toggle="tab">Security</a></li>
		</ul>

		<!-- Tab panes -->
		<div class="tab-content">
			<div role="tabpanel" class="tab-pane active" id="Profile">
				<h3>Profile Information</h3>
				<form>
				  <div class="form-group">
					<label for="exampleInputEmail1">Email address</label>
					<input type="email" class="form-control" id="exampleInputEmail1">
				  </div>
				  <div class="form-group">
					<label for="exampleInputPassword1">Password</label>
					<input type="password" class="form-control" id="exampleInputPassword1">
				  </div>
				  <div class="form-group">
					<label for="exampleInputPassword1">A little bit about yourself</label>
					<textarea class="form-control" rows="3"></textarea>
				  </div>
				  <div class="form-group">
					<label for="exampleInputFile">File input</label>
					<input type="file" id="exampleInputFile">
					<p class="help-block">Example block-level help text here.</p>
				  </div>
				  <div class="checkbox">
					<label>
					  <input type="checkbox"> Check me out
					</label>
				  </div>
				  <button type="submit" class="btn btn-success">Submit</button>
				</form>
			</div>
			<div role="tabpanel" class="tab-pane" id="Notification">
			<h3>Notification Preferences</h3>
				<!-- List group -->
				<ul class="list-group">
					<li class="list-group-item">
						Bootstrap Switch Success
						<div class="material-switch pull-right">
							<input id="uccess1" name="someSwitchOption001" type="checkbox"/>
							<label for="uccess1" class="label-success"></label>
						</div>
					</li>
					<li class="list-group-item">
						Bootstrap Switch Success
						<div class="material-switch pull-right">
							<input id="uccess2" name="someSwitchOption001" type="checkbox"/>
							<label for="uccess2" class="label-success"></label>
						</div>
					</li>
					<li class="list-group-item">
						Bootstrap Switch Success
						<div class="material-switch pull-right">
							<input id="Success3" name="someSwitchOption001" type="checkbox"/>
							<label for="Success3" class="label-success"></label>
						</div>
					</li>
					<li class="list-group-item">
						Bootstrap Switch Success
						<div class="material-switch pull-right">
							<input id="Success4" name="someSwitchOption001" type="checkbox"/>
							<label for="Success4" class="label-success"></label>
						</div>
					</li>
					<li class="list-group-item">
						Bootstrap Switch Success
						<div class="material-switch pull-right">
							<input id="Success5" name="someSwitchOption001" type="checkbox"/>
							<label for="Success5" class="label-success"></label>
						</div>
					</li>
					<li class="list-group-item">
						Bootstrap Switch Success
						<div class="material-switch pull-right">
							<input id="Success6" name="someSwitchOption001" type="checkbox"/>
							<label for="Success6" class="label-success"></label>
						</div>
					</li>
				</ul>
				</div>
			<div role="tabpanel" class="tab-pane" id="Security">
			<h3>Change Password</h3>
				<form>
				  <div class="form-group">
					<label for="exampleInputEmail1">Current password</label>
					<input type="password" class="form-control" id="inputPassword" placeholder="Password">
				  </div>
				  <div class="form-group">
					<label for="exampleInputEmail1">New password</label>
					<input type="password" class="form-control" id="inputPassword" placeholder="Password">
				  </div>
				  <div class="form-group">
					<label for="exampleInputPassword1">Verify password</label>
					<textarea class="form-control" rows="3"></textarea>
				  </div>

				  <div class="checkbox">
					<label>
					  <input type="checkbox"> You want to change the password
					</label>
				  </div>
				  <button type="submit" class="btn btn-warning">Submit</button>
				</form>
				<hr />
				<div class="checkbox">
					<label>
					  <input type="checkbox"> You want to Delete your Account
					</label>
				  </div>
				  <button type="submit" class="btn btn-danger">Submit</button>
				<br><br>
				<p>Please note that this action is irreversible and all the data associated with your account will be permanently deleted in 30 days</p>
			</div>
		</div>
		</div>         
	</div>
	</div>
</div>

 <?php $this->load->view("footer"); ?>
