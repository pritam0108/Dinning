<div class="container">
<form class="form-inline" role="form" method="GET" action="<?php echo base_url('res_search');?>">
<!--input type="hidden" name="hdnSearchid"  /-->
  <div class="form-group col-md-3 col-sm-3 col-md-offset-1 padding_l_r">
    <input type="text" id="location" name="location"  class="form-control input-lg input-block" placeholder="City" >
  </div>

  <div class="form-group col-md-5 col-sm-7 padding_l_r">
    <input type="text" id="resTitle" name="resTitle" class="form-control input-lg input-block" placeholder="Search for restaurants and cuisines....">
  </div>

  <div class="padding_l_r col-md-2 col-sm-2"><button type="submit" class="btn btn-success btn-lg btn-block"><i class="fa fa-search"></i> Search </button></div>
</form>
</div>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>

	<script>
	$(function(){   	    
	$( "#location" ).autocomplete({
      //source: availableTags
	  source: function(request, response) {
			$.ajax({ url: "<?php echo site_url('home/get_location'); ?>",
			data: { loc: $("#location").val()},
			dataType: "json",
			type: "POST",
			success: function(data){
			response(data);
			}
		  });
	  }
    });
	
    });
    </script>