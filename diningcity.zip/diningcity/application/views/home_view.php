<?php $this->load->view("header");?>

     <!-- Navigation -->
    <nav class="navbar navbar-inverse" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <!--button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button-->
                <button style="margin-top:8px;" type="button" class="btn btn-success" id="logId" data-toggle="modal" data-target="#myModal">Log in</button>
               <!-- Modal -->
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title text-danger" id="myModalLabel">Sign up or log in to DinnerCity</h4>
                      </div>
                      <div class="modal-body">
                        <ul class="nav nav-tabs final-login">
                            <li class="active"><a data-toggle="tab" href="#sectionA">Sign In</a></li>
                            <li><a data-toggle="tab" href="#sectionB">Join us!</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="sectionA" class="tab-pane fade in active">
                                <div class="innter-form">
                                    <?php
                                    echo form_open('home','class="myclassA"');
                                    ?>

                                    <form method="post" action="<?php echo site_url('home')?>">
                                    <div class="form-group">
                                    <?php
                                        echo form_label('Email','email');
                                        echo form_input('email','','class="form-control" id="email" placeholder="Email" required');
                                    ?>
                                    </div>
                                    <div class="form-group">
                                    <?php
                                        echo form_label('Password','password');
                                        echo form_input('password','','class="form-control" id="password" placeholder="Password" required');
                                    ?>
                                    </div>
                                    <?php echo form_submit('home', 'Login', 'class="btn btn-primary"') ?>
                                    
                                    <br><br>
                                    <i style="font-size: 9pt">By logging in, you agree to DinnerCity's Terms of Service and Content Policies.</i>
                                    <?php echo form_close() ?>
                                </div>
                                    <div class="clearfix"></div>
                            </div>  

                            <div id="sectionB" class="tab-pane fade">
                                <div class="innter-form">
                                    <?php
                                    echo form_open('home/register','class="myclassB"');
                                    ?>

                                    <form method="post" action="<?php echo base_url('home') ?>">
                                    <div class="form-group">
                                    <?php
                                        echo form_label('Name','fname');
                                        echo form_input('fname','','class="form-control" id="fname" placeholder="Name" required');
                                    ?>
                                    </div>    
                                    <div class="form-group">
                                    <?php
                                        echo form_label('Email','email');
                                        echo form_input('email','','class="form-control" id="email" placeholder="Email" required');
                                    ?>
                                    </div>
                                    <div class="form-group">
                                    <?php
                                        echo form_label('Password','password');
                                        echo form_input('password','','class="form-control" id="password" placeholder="Password" required');
                                    ?>
                                    </div>
                                    <?php echo form_submit('abcd', 'Sign up', 'class="btn btn-primary"') ?>
                                    
                                    <br><br>
                                    <i style="font-size: 9pt">By logging in, you agree to DinnerCity's Terms of Service and Content Policies.</i>
                                    <?php echo form_close() ?>
                                </div>
                            
                            </div>

                            
                       </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
                
            </div>


            <!-- Collect the nav links, forms, and other content for toggling -->
            <!--div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Services</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div-->
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Full Width Image Header with Logo -->
    <!-- Image backgrounds are set within the full-width-pics.css file. -->
    <div class="image-bg-fluid-height">
         <div class="logo text-center">
         <a href="<?php base_url(); ?>"><span>DiningCity</span></a>
         </div>
        <!--<img class="img-responsive img-center" src="http://placehold.it/200x200&text=Logo" alt="logoimg">-->
        <div class="search-panel">

            <h2>Find the best restaurants, cafés, and bars</h2>         
            <?php $this->load->view("home_res_search");?>

        </div>        

    </div>


    <!-- Content Section -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="section-heading">Section Heading</h1>
                    <p class="lead section-lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <p class="section-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid, suscipit, rerum quos facilis repellat architecto commodi officia atque nemo facere eum non illo voluptatem quae delectus odit vel itaque amet.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Fixed Height Image Aside -->
    <!-- Image backgrounds are set within the full-width-pics.css file. -->
    <aside class="image-bg-fixed-height"></aside>

    <!-- Content Section -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="section-heading">Section Heading</h1>
                    <p class="lead section-lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <p class="section-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid, suscipit, rerum quos facilis repellat architecto commodi officia atque nemo facere eum non illo voluptatem quae delectus odit vel itaque amet.</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>


<script type="text/javascript">
    $(document).ready(function(){

        $('#logId').click(function(){
            $('#backdrop').animate({'opacity':'.8'},300,'linear');
            $('#backdrop,#dropbox').css('display', 'block');
        });

        $('#close').click(function(){

            close_tab();
        });
        $('#backdrop').click(function(){

            close_tab();
        });
        function close_tab(){
            $('#dropbox,#backdrop').css('display','none');
        }

    });
</script>

</body>
</html>
    