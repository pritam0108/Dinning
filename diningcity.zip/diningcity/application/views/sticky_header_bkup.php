<?php $this->load->view("header"); ?>


<nav class="navbar navbar-default navbar-static-top">
  <div class="container">

	<form class="form-inline" role="form" method="POST" action="">
	<input type="hidden" name="hdnSearch" value="search" />
		<table>
			<tr>
				<td><input id="location" type="text" name="location" class="form-control" placeholder="City" required ></td>
				<!--<td><input type="text" id="location" name="location" class="form-control" placeholder="Zipcode or City State"></td>-->
				<td><input type="text" id="cuisineTitle" name="cuisineTitle" class="form-control" placeholder="Search for restaurants and cuisines...."></td>
				<td style="width:100px;" valign="top">
					<!--a href="#" class="btn btn-default btn-lg"><i class="fa fa-search"></i> Start Search </a!-->
					<button type="submit" class="btn btn-danger"><i class="fa fa-search"></i> Search </button>
				</td>
				 <ul class="nav navbar-nav navbar-right">
			        <li class="dropdown">
			          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown<span class="caret"></span></a>
			          <ul class="dropdown-menu">
                        <li><a href="<?php echo base_url('dashboard/settings') ?>">Settings</a></li>
                        <li><a href="<?php echo base_url('dashboard/logout') ?>">Logout</a></li>
			          </ul>
			        </li>
			     </ul> 
			</tr>
		</table>
	</form>
 
  </div>
</nav>

	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>

	<script>
	$(function(){   	    
	$( "#location" ).autocomplete({
      //source: availableTags
	  source: function(request, response) {
			$.ajax({ url: "<?php echo site_url('home/get_location'); ?>",
			data: { termLocation: $("#location").val()},
			dataType: "json",
			type: "POST",
			success: function(data){
				response(data);
			}
		  });
	  }
    });
	
    });
    </script>