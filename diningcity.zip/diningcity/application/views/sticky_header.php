
<nav class="navbar navbar-default">
  <div class="container">
	<div class="row">
		<div class="col-md-2 col-sm-3">
			<div class="logo logo-inner pull-left">
				<a href="<?php base_url(); ?>"><span>DiningCity</span></a>
			</div>
		</div>
		<div class="col-md-8 col-sm-6">
			<div class="row">
				<form class="form-inline head-form" role="form" method="POST" action="">
				<input type="hidden" name="hdnSearch" value="search" />
					<div class="form-group col-md-4 col-sm-4 padding_l_r"><input id="location" type="text" name="location" class="form-control input-block ui-autocomplete-input" placeholder="City" required="" ></div>
					<div class="form-group col-md-5 col-sm-5 padding_l_r"><input type="text" id="cuisineTitle" name="cuisineTitle" class="form-control input-block" placeholder="Search for restaurants and cuisines...."></div>
					<div class="form-group col-md-3 col-sm-3 padding_l_r">
						<button type="submit" class="btn btn-success btn-block"><i class="fa fa-search"></i> Search </button>
					</div>
				</form>
			</div>
		</div>
		<div class="col-md-2 col-sm-3">
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
				  <ul class="dropdown-menu">
					<li><a href="<?php echo base_url('dashboard/settings') ?>">Settings</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="<?php echo site_url('dashboard/logout') ?>">Logout</a></li>
				  </ul>
				</li>
			</ul>
		</div>
  </div>
</nav>

	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>

	<script>
	$(function(){   	    
	$( "#location" ).autocomplete({
      //source: availableTags
	  source: function(request, response) {
			$.ajax({ url: "<?php echo site_url('home/get_location'); ?>",
			data: { termLocation: $("#location").val()},
			dataType: "json",
			type: "POST",
			success: function(data){
				response(data);
			}
		  });
	  }
    });
	
    });
    </script>