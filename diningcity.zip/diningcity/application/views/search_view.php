 <?php $this->load->view("header"); ?>
 <!--?php $this->load->view("sticky_header"); ?-->
 <div class="container" style="margin-top: 20px; margin-bottom: 20px;">
<h2>Breakfast in Bhubaneswar</h2>
	<div class="row">
	<div class="col-md-3 col-sm-3">
		<div class="panel panel-default">
		  <!--div class="panel-body">
			<form>
				<!--div class="checkbox">
				<label>
				  <input type="checkbox"> Check me out
				</label>
			  </div>
			</form>
		  </div-->
		</div>
		<div class="panel panel-default">
	    <div class="panel-heading">Filters</div>

		  <div class="panel-heading">Sort by</div>
		  <div class="panel-body">
			<a href="#">Popularity <span class="text-muted"> - high to low</span></a>
		  </div>
		  <div class="panel-body">
			<a href="#">Rating <span class="text-muted"> - high to low</span></a>
		  </div>
		  <div class="panel-body">
			<a href="#">Cost <span class="text-muted"> - high to low</span></a>
		  </div>
		  <div class="panel-body">
			<a href="#">Cost <span class="text-muted"> - low to high</span></a>
		  </div>
		  <div class="panel-body">
			<a href="#">Recently added</a>
		  </div>	

		  <div class="panel-heading">Category</div>
		  <div class="panel-body">
			<a href="#">Dine-Out </a>
		  </div>	
		  <div class="panel-body">
			<a href="#">Cafés </a>
		  </div>

		  <div class="panel-heading">Location</div>
		  <div class="panel-body">
			<a href="#">Patia </a>
		  </div>	
		  <div class="panel-body">
			<a href="#">Sahid Nagar </a>
		  </div>	
		  <div class="panel-body">
			<a href="#">Jayadev Vihar </a>
		  </div>		
		  <div class="panel-body">
			<a href="#">Chandrasekharpur </a>
		  </div>	
		  <div class="panel-body">
			<a href="#">BJB Nagar </a>
		  </div>		  


<!-- ------------------------------>	


		  <div class="panel-heading">Cost for two</div>
		  <div class="panel-body">
			<a href="#">Less than ₹250 </a>
		  </div>	
		  <div class="panel-body">
			<a href="#">₹250 to ₹500 </a>
		  </div>	
		  <div class="panel-body">
			<a href="#">₹500 to ₹1,000 </a>
		  </div>		
		  <div class="panel-body">
			<a href="#">₹1,000 to ₹1,500 </a>
		  </div>	
		  <div class="panel-body">
			<a href="#">₹1,500 to ₹2,500 </a>
		  </div>	
		  <div class="panel-body">
			<a href="#">₹2,500 + </a>
		  </div>		  	  		    	  		   


	  </div>
	</div>
	<div class="col-md-9 col-sm-9">
		<hgroup class="mb20">
		<h1>Search Results</h1>
		<h2 class="lead">
			
		<?php
        if($this->input->get("resTitle")!="") { ?>
		<strong class="text-danger"><?php echo $total_row_res ?></strong> result was found for the search <strong class="text-danger">"<?php echo $result ?>"</strong>
		<?php }  elseif($this->input->get("location")!=""){ ?> 

		<strong class="text-danger"><?php echo $total_row_loc ?></strong> results were found for the search <strong class="text-danger">"<?php echo $resultLoc ?>"</strong> <?php  } ?>		

		</h2>		


	</hgroup>

    <div class="col-xs-12 col-sm-12">
	<?php	
    //if($this->input->get("resTitle")!= "") {		
	//if(is_array($searchList)) {
	foreach ($searchList as $row){?>	
		<article class="search-result row">
			<div class="col-xs-12 col-sm-12 col-md-3">
				<a href="#" title="Lorem ipsum" class="thumbnail"><img src="http://lorempixel.com/250/140/people" alt="Lorem ipsum" /></a>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-7 excerpet">
				<p class="text-success"><?php echo $row->type_name; ?></p>
				<h3><a href="#" title=""><?php echo $row->res_name; ?></a></h3>

				<p class="text-danger"><?php echo $row->loc_name; ?></p> 	
				<p class="text-info"> <?php echo $row->add_details;?>, <?php echo $row->loc_name; ?>, <?php echo $row->city_name; ?></p>		

				<p class="text-info">CUISINES:	<?php echo $row->cuisine_name; ?></p>						
				<p class="text-info">COST FOR TWO:	₹<?php echo $row->cost; ?></p>						
				<p class="text-info"> <?php echo $row->contact; ?></p>						
			</div>
			<span class="clearfix borda"></span>
		</article>		
	<?php } ?>


	</div>
	</div>
	</div>
	<div>
		<?php echo $pagination; ?> 
	</div>
</div>

 <?php $this->load->view("footer"); ?>


<script>
	$(function () {
	  $('[data-toggle="tooltip"]').tooltip()
	})
	
$( ".cuisinebox" ).click(function() {
  $( "#frmMain" ).submit();
});






</script>