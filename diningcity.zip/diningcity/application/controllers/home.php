<?php

class Home extends CI_Controller {

	public function __construct()  {
		parent::__construct();

		$this->load->model('common_model');
	}

	public function index()
	{
		//error_reporting(E_ALL);
		//$id = $this->input->post('searchId', TRUE);
		//$data['hdnSearchid'] = $this->common_model->Retrive_Record('t_search',$id);

		$data= array();
		$this->form_validation->set_rules('email','Email','trim|required');
		$this->form_validation->set_rules('password','Password','trim|required|callback_login_chk');
		if($this->form_validation->run()==false)
		{
			$this->load->view("home_view",$data);
		} else{
			redirect(base_url('dashboard'),'refresh');
		}


	}

	public function login_chk($password)
	{
		$email= $this->input->post('email');
		$result= $this->common_model->login($email, $password);

		if($result)
		{
			$sess_array= array();
			foreach ($result as $row) {
				$sess_array= $arrayName = array('id' => $row->id, 'email' => $row->email, 'fname' => $row->fname);
				$this->session->set_userdata('logged_in', $sess_array);
			}
			return true;
		}	else{
			$this->form_validation->set_message('login_chk','Invalid username or password');
			return false;
		}
	}

	public function register()
	{
		if($this->input->post('abcd')){
			$this->common_model->register();
			redirect('home');
		} else{
			$this->load->view('home_view');
		}
	}
		public function search()
	{
		$this->load->view("search_view");
	}

	public function get_location()
	{
		$q = strtolower($_POST["loc"]);
		if (!$q) return;
		/*************City***************/
		$sql = "SELECT loc_name FROM t_location WHERE loc_name LIKE '%".$q."%' LIMIT 10 ";
		$query = $this->db->query($sql);
		//echo $this->db->last_query();
		$result_arr = $query->result();
		$json_array = array();
		foreach ($result_arr as $row){
			array_push($json_array, $row->loc_name);
		}	

		echo json_encode($json_array);
	}	
}
