<?php

class Res_search extends CI_Controller {

	public function __construct()  {
		parent::__construct();

		$this->load->model('common_model');
        $this->table = 't_search';	

	}

	public function index()
	{
		error_reporting(E_ALL & ~E_NOTICE);
		$message = '';

		$order_by_fld = 'status';
		$order_by = 'DESC';

		$where_clause = "status = 'Y' ";
		$where_clause1 = "status = 'Y' ";

		if($this->uri->segment(3) == '' && $this->uri->segment(2)!='index' && $this->session->userdata('mode')=='')
		{
			$this->session->set_userdata('resTitle', '');

			$this->session->set_userdata('res_name', '');
			$this->session->set_userdata('type', '');
			$this->session->set_userdata('contact', '');


			$data['resTitle'] = '';	

				
		}

		if($this->input->post('hdnSearch')!='')
		{
			$resTitle = $this->input->post('resTitle');
			$this->session->set_userdata('resTitle', $resTitle);

			$res_name = $this->input->post('res_name');
			$this->session->set_userdata('res_name', $res_name);			
			
			$type = $this->input->post('type');
			$this->session->set_userdata('type', $type);

			$contact = $this->input->post('contact');
			$this->session->set_userdata('contact', $contact);			
				
			
		}

		else
		{
			$resTitle =$this->session->userdata('resTitle');

			$res_name =$this->session->userdata('res_name');
			$type =$this->session->userdata('type');
			$contact =$this->session->userdata('contact');

		}	

		if($this->session->userdata('resTitle') != '')
		{	
			$placeholders = array(' ', '&', ':', '/', 'or', 'OR', 'Or', 'AND', 'and', 'AND', '-');
			$filterstr = array(',', ',', ',', ',', ',', ',', ',', ',', ',', ',', ',');
			$resTitleArr="";
			$resTitleArr = explode(",",str_replace($placeholders, $filterstr, $resTitle));        
			$qryflag=true;
			$disp = "1";
			$qry1.="AND (  ";
			foreach($resTitleArr as $key => $value)
			{	
				if($value	!='')
				{

						$skqry.= "((res_name LIKE '%".$value."%') or (type LIKE '%".$value."%') or (contact LIKE '%".$value."%')) OR "; 
				}
			}
			$qry1.=substr($skqry,0,(strlen($skqry)-3)); 
			$qry1.=")";
				$where_clause .= $qry1;
				$where_clause1 = $where_clause;
		}


		if ($this->session->userdata('res_name') != '')
		{
			//$where_clause1 = $where_clause;
			$where_clause1.=" AND ( ";  
			foreach($res_name as $Val){
				//$val=ucfirst($indVal);
				$qryResName.=" (res_name LIKE '%".$Val."%') OR ";
			}
			$qryflag=true;
			$disp = "1";
			$where_clause1.=substr($qryResName,0,(strlen($qryResName)-3));
			$where_clause1.=")";
			//echo $where_clause1 ;
		}

		if ($this->session->userdata('type') != ''){
			$where_clause1.=" AND (";  
			foreach($type as $val){
				$qryType.=" (type = '".$val."') OR ";
			}
			$qryflag=true;
			$disp = "1";
			$where_clause1.=substr($qryType,0,(strlen($qryType)-3));
			$where_clause1.=")";
		}	

		if ($this->session->userdata('contact') != '')
		{
			$where_clause1.=" AND (";  
			foreach($contact as $val){
				$qryContact.=" (contact = '".$val."') OR ";
			}
			$qryflag=true;
			$disp = "1";
			$where_clause1.=substr($qryContact,0,(strlen($qryContact)-3));
			$where_clause1.=")";
		}

		$query="";
		if($resTitle!="")
		{
			
				//$where_clause1 = $qry1;
		//$data['where_clause'] = $where_clause;
		$data['resTitle'] = $resTitle;
		//$data['res_name'] = $res_name;
		//$data['type'] = $type;
		//$data['contact'] = $contact;

		//$offset = (int)$this->uri->segment(3,0);
		//$limit= 15;
		$total_rows = $this->common_model->countAll($this->table,$where_clause1);		
		$query = $this->common_model->get_all_records($this->table, $where_clause1,$order_by_fld,$order_by,$offset,$limit);
		//$query_city = $this->common_model->get_all_records('t_city',$where_clause,"",'ASC',"","");			
		//$query_location = $this->common_model->get_all_records('t_location',$where_clause,"",'ASC',"","");	
	
	
		//$query1 = $this->common_model->get_all_distinct_records($this->table,'res_name');
		//$query2 = $this->common_model->get_all_distinct_records($this->table,'type');
		//$query3 = $this->common_model->get_all_distinct_records($this->table,'contact');



		$data['total_rows'] = $total_rows;
		$data['offset'] = $offset;
		//$data['paginator'] = $paginator;
		$data['message'] = $message;
		$data['order_by_fld'] = $order_by_fld;
		$data['order_by'] = $order_by;
		$data['query'] = $query;
		//$data['query1'] = $query1;
		//$data['query2'] = $query2;
		//$data['query3'] = $query3;			

		}					

		else {
		//$data['where_clause'] = $where_clause;
		$data['resTitle'] = $resTitle;
		//$data['res_name'] = $res_name;
		//$data['type'] = $type;
		//$data['contact'] = $contact;

		$offset = (int)$this->uri->segment(3,0);
		//$limit= 15;
		$total_rows = $this->common_model->countAll($this->table,$where_clause1);		
		$query = $this->common_model->get_all_records($this->table, $where_clause1,$order_by_fld,$order_by,$offset,$limit);
		//$query_location = $this->common_model->get_all_records('t_location',$where_clause,"",'ASC',"","");			

		//$query1 = $this->common_model->get_all_distinct_records($this->table,'res_name');
		//$query2 = $this->common_model->get_all_distinct_records($this->table,'type');
		//$query3 = $this->common_model->get_all_distinct_records($this->table,'contact');		

		$data['total_rows'] = $total_rows;
		$data['offset'] = $offset;
		//$data['paginator'] = $paginator;
		$data['message'] = $message;
		$data['order_by_fld'] = $order_by_fld;
		$data['order_by'] = $order_by;
		$data['query'] = $query;
		//$data['query1'] = $query1;
		//$data['query2'] = $query2;
		//$data['query3'] = $query3;		
	}

		$this->load->view("search_view",$data);


	}


}
