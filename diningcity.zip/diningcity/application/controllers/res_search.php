<?php

class Res_search extends CI_Controller {

	public function __construct()  {
		parent::__construct();

	$this->load->model('common_model');
        $this->table = 't_search';	
	}


	public function index()
	{
	//error_reporting(E_ALL & ~E_NOTICE);
	$where_clause = "status = 'Y' ";
        $search = ($this->input->get("resTitle"))? $this->input->get("resTitle") : "NIL";
        $search = ($this->uri->segment(3)) ? $this->uri->segment(3) : $search;
        //echo $search;

        $searchLoc = ($this->input->get("location"))? $this->input->get("location") : "NIL";
        $searchLoc = ($this->uri->segment(3)) ? $this->uri->segment(3) : $searchLoc;

        //echo $search;

        // pagination settings
        //if($search!= "")
        //{

       if($this->input->get("resTitle")!="" )
       {
        //echo $search;
        $total_row_res=  $this->common_model->res_count($search,"") ;
        $limit = 3;        

        //$config = array();
        $config['base_url'] = base_url()."res_search/index/$search";
        //print_r($config['base_url']);
        $config['total_rows'] =  $total_row_res;
        //echo $config['total_rows'];
        $config['per_page'] = $limit;
        $config["uri_segment"] = 4;
        $choice = $config["total_rows"]/$config["per_page"];
        $config["num_links"] = floor($choice);   

        //print_r($config["num_links"]);
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);     

       $data['result']=$search;

       $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
       $data['searchList'] = $this->common_model->search($this->table, $search, $searchLoc, $limit, $data['page']);
       $data['total_row_res'] = $total_row_res;
       echo $total_row_res;
        $data['pagination'] = $this->pagination->create_links();        

            
      }
       else{
        //echo $search;
        $total_row_loc=  $this->common_model->res_count("",$searchLoc) ;
        $limit = 5;        

        //$config = array();
        $config['base_url'] = base_url()."res_search/index/$searchLoc";
         //print_r($config['base_url']);
        $config['total_rows'] =  $total_row_loc;
        //echo $config['total_rows'];
        $config['per_page'] = $limit;
        $config["uri_segment"] = 4;
        $choice = $config["total_rows"]/$config["per_page"];
        $config["num_links"] = floor($choice);         

        //print_r($config["num_links"]);
    
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);     

       $data['resultLoc']=$searchLoc;
       $data['total_row_loc'] = $total_row_loc;
       echo $total_row_loc;
       $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
       $data['searchList'] = $this->common_model->search($this->table, $search, $searchLoc, $limit, $data['page']);
        $data['pagination'] = $this->pagination->create_links();        


   }



       /*if($this->input->get("location")!= "") {
        //echo $searchLoc;
        $config = array();
        $config['base_url'] = base_url()."res_search/index";
        $config['total_rows'] = $this->common_model->res_count("",$searchLoc);   
        echo $config['total_rows'];
        $config['per_page'] = "5";
        $config["uri_segment"] = 4;
        $choice = $config["total_rows"]/$config["per_page"];
        $config["num_links"] = floor($choice);        

        //print_r($config["num_links"]);
    
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);         

       $data['result_loc']=$searchLoc;
       $data['total_row_loc']=  $this->common_model->res_count("",$searchLoc) ;

       $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
       $data['searchList'] = $this->common_model->search($this->table, $search, $searchLoc, $config['per_page'], $data['page']);  
       }*/
  


       

        //}


        /*if($searchLoc!="")
        {
        $config = array();
        $config['base_url'] = base_url()."res_search/index/$searchLoc";

        $config['total_rows1'] = $this->common_model->res_count($searchLoc);
        //echo $config['total_rows1'];


        $config['per_page'] = "5";
        $config["uri_segment"] = 4;
        $choice = $config["total_rows1"]/$config["per_page"];
        $config["num_links"] = floor($choice);  

      
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);        


        $data['result_loc']=$searchLoc;

        $data['total_row_loc']= $config['total_rows1'] ;

 
        }*/


       /*if($search!= "")
       {
       $data['result']=$search;
       $data['total_row_res']=  $this->common_model->res_count($search,"") ;

       $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
       $data['searchList'] = $this->common_model->search($this->table, $search, $searchLoc, $config['per_page'], $data['page']);            
       }
       if($searchLoc!= "")
       {
       $data['result_loc']=$searchLoc;
       $data['total_row_loc']=  $this->common_model->res_count("",$searchLoc) ;

       $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
       $data['searchList'] = $this->common_model->search($this->table, $search, $searchLoc, $config['per_page'], $data['page']);            
       } */
       
        //print_r($config["num_links"]);

        // integrate bootstrap pagination


        //$data['resultLoc']=$searchLoc;
        //$data['searchid'] = $_GET['searchId'];
        //print_r($data['searchid']);

        //if($this->input->get("resTitle")!="")
        //{
        //$data['result']=$search;

        //$data['total_row_res'] = $config['total_rows'];


       // $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
       // $data['searchList'] = $this->common_model->search($this->table, $search, $searchLoc, $config['per_page'], $data['page']);






        /*if($this->input->get("location"))
        {
        //$data['resultLoc']=$searchLoc;

        $data['total_row']=$this->common_model->res_count($searchLoc);
        $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        $data['searchList'] = $this->common_model->search($this->table, $search,$searchLoc, $config['per_page'], $data['page']);               
        } */
        /*if($this->input->get("location")!=""){
        $data['total_row_loc'] = $config['total_rows1'];
        $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        $data['searchList'] = $this->common_model->search($this->table, $search,$searchLoc, $config['per_page'], $data['page']);
        } */

        //print_r($data['page']);
        

        //print_r($data['searchList']);
        //$data['locationList'] =  $data['searchList'];
        //$data['query1'] = $this->common_model->get_all_distinct_records($this->table,'cuisine_name');


      /*  $searchList = $data['searchList'];
        foreach($searchList as $key => $value)
        {
                $sid =  $value->searchId;
                //echo $sid;
        }*/

        //$data['query1'] = $this->common_model->Retrive_Record($this->table,$sid);


       // $data['query_location'] = $this->common_model->get_All_location('t_location',$search);

        $data['where_clause'] = $where_clause;
        //$data['pagination'] = $this->pagination->create_links();        

        //var_dump($data);
        //exit();

        $this->load->view("search_view",$data);


	}



}
