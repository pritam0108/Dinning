<?php

class Dashboard extends CI_Controller {


	public function index()
	{
		if($this->session->userdata('logged_in')){
				$session_data = $this->session->userdata('logged_in');
				$data['id']= $session_data['id'];
				$data['fname']= $session_data['fname'];
				$data['email']= $session_data['email'];

				//$data['password']= $session_data['password'];
				$this->load->view('dashboard_view',$data);	
		} else{
			redirect('home', 'refresh');
		}

	}

	public function settings()
	{
		$this->load->view("settings_view");
	}
	
	public function profile()
	{
		$this->load->view("profile_view");
	}


	public function logout()
	{
		$this->session->unset_userdata('logged_in');
		$this->session->sess_destroy();
		redirect(base_url('home'), 'refresh');
	}


}
