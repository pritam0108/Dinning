<?php

define('CITY','t_location');

?>